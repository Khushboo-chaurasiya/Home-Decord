import React from 'react';
import './App.css';

import RouterPage from './RouterPage';

function App() {
  return (
      <RouterPage />
  );
}

export default App;
