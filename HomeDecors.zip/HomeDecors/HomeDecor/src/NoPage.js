import React from 'react'

function NoPage() {
    return (
        <div>
            No page 404
        </div>
    )
}

export default NoPage
